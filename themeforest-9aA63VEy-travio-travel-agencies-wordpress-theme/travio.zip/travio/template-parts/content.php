<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package travio
 */
get_template_part('template-parts/blog-layout/blog-standard-content');
?>

